﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SoftJail.Common
{
    public class ValidationConstants
    {
        //Prisoner
        public const int PrisonerFullNameMinLength = 3;
        public const int PrisonerFullNameMaxLength = 20;
        //Officer
        public const int OfficerFullNameMinLength = 3;
        public const int OfficerFullNameMaxLength = 30;
        //Department
        public const int DepartmentFullNameMinLength = 3;
        public const int DepartmentFullNameMaxLength = 25;
    }
}
