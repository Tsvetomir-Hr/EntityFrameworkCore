﻿namespace P01_StudentSystem.Data.Common
{
    public class DbConfig
    {
        public const string connectionString = @"Server=CECOPC\SQLEXPRESS;Database=StudentSystem;Integrated Security=True;Encrypt=False;";

    }
}