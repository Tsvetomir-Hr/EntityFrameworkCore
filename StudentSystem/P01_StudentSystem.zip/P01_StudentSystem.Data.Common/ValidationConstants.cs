﻿namespace P01_StudentSystem.Data.Common;

public class ValidationConstants
{
    public const int studentNameMaxLength = 100;

    public const int phoneNumberLength = 10;

    public const int CourseNameMaxLength = 80;

    public const int ResourceNameMaxLength = 50;

}
