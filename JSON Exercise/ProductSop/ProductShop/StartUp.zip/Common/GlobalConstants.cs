﻿namespace ProductShop.Common;

public class GlobalConstants
{
    public const int UserLastNameMinLength = 3;
}
